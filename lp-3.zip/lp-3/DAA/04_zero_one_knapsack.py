def knapsack(values, weights, capacity):
    n = len(values)
    dp = [[0 for _ in range(capacity + 1)] for _ in range(n + 1)]
    for i in range(1, n + 1):
        for w in range(capacity + 1):
            if weights[i-1] <= w:
                dp[i][w] = max(values[i-1] + dp[i-1][w-weights[i-1]], dp[i-1][w])
            else:
                dp[i][w] = dp[i-1][w]
    selected_items = []
    w = capacity
    for i in range(n, 0, -1):
        if dp[i][w] != dp[i-1][w]:
            selected_items.append(i-1) 
            w -= weights[i-1]
    max_value = dp[n][capacity]
    selected_items.reverse() 
    return max_value, selected_items


num_items = int(input("Enter the number of items: "))
values = list(map(int, input("Enter the values of the items separated by space: ").split()))
weights = list(map(int, input("Enter the weights of the items separated by space: ").split()))
capacity = int(input("Enter the maximum capacity of the knapsack: "))

max_value, selected_items = knapsack(values, weights, capacity)

print("Maximum value achievable:", max_value)
print("Selected item indices (0-based):", selected_items)
print("Selected item values:", [values[i] for i in selected_items])
print("Selected item weights:", [weights[i] for i in selected_items])
